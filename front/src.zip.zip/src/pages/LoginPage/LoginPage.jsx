import Login from "../../modules/Login/Login";

const LoginPage = () => {
    return (
        <main className="layout">
            
                <div className="container">
                    <Login />
                </div>
            
        </main>
    )
}

export default LoginPage;