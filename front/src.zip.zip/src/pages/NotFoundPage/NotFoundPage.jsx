import NotFound from "../../modules/NotFound/NotFound";

const NotFoundPage = () => {
    return (
        <div className="layout">
            <NotFound />    
        </div>
    )
}

export default NotFoundPage;