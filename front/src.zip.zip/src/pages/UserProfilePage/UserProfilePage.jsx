import User from "../../modules/User/User"; 

const UserProfilePage = () => {
    return (
        <main className="user-profile-page">
            <User/>
        </main>
    )
}

export default UserProfilePage;