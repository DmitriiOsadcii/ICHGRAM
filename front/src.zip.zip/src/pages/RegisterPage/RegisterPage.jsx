import Register from "../../modules/Register/Register";

const RegisterPage = () => {
    return (
        <main className="register-page">
            <div className="layout" >
                <Register />
            </div>  
        </main>
    )
}

export default RegisterPage;