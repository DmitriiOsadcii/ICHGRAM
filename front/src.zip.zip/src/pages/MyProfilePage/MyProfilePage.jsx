import MyProfile from "../../modules/MyProfile/MyProfile";

const MyProfilePage = () => {
    return (
        <main className="layout">
            <MyProfile />
        </main>
    )
}

export default MyProfilePage;