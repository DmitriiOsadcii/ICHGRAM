import Main from "../../modules/Main/Main";

const MainPage = () => {
    return (
        <div className="layout">
            <Main />
        </div>
    )
}

export default MainPage;