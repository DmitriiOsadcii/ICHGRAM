
import Post from "../../modules/Post/Post";

const PostPage = () => {
  return (
    <main>
      <div className="layout" >
        <Post />
      </div>
    </main>
  )
};

export default PostPage;