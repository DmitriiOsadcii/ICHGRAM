import Explorer from "../../modules/Explorer/Explorer";

const ExplorePage = () => {
    return (
        <main className="layout">
            <Explorer />
        </main>
    )
}

export default ExplorePage;