import EditProfile from "../../modules/EditProfile/EditProfile";

const EditProfilePage = () => {
    return (
        <main className="layout">
            <EditProfile />
        </main>
    )
}

export default EditProfilePage;