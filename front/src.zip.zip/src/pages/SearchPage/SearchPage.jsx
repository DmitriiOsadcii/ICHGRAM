

const SearchPage = () => {
    return (
        <main>
        </main>
    )
}

export default SearchPage;