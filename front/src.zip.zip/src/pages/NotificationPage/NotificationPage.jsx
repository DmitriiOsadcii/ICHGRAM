import Post from "../../modules/Post/Post";

const NotificationPage = () => {
    return (
        <main >
            <Post />
        </main>
    )
}

export default NotificationPage;