import type { RootState } from "../store";

export const selectModal = (store: RootState)=> store.modal.modalStack