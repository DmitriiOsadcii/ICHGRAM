import { createAsyncThunk } from "@reduxjs/toolkit";

import { forgotPasswordApi, loginApi, logoutApi, registerApi, resendEmailApi, verifyUserApi } from "../../shared/api/auth.api"
import { updateMyProfileApi } from "../../shared/api/myProfile.api"
import { AxiosError } from "axios";
import { getCurrentApi } from "../../shared/api/auth.api";
import type { RootState } from "../store";

import type { IResendVerificationEmaiPayload, IForgotPasswordPayload, IAuthResponse, ILoginPayload, IRegisterPayload, IUser, IUpdateMyProfilePayload } from "../../typescript/interfaces"

export const registration = createAsyncThunk<{ message: string }, IRegisterPayload, { rejectValue: string }>("auth/register", async (payload, { rejectWithValue }) => {
    try {
        const data = await registerApi(payload)
        return data;
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const login = createAsyncThunk<IAuthResponse, ILoginPayload, { rejectValue: string }>("/auth/login", async (payload, { rejectWithValue }) => {
    try {
        const data = await loginApi(payload)
        return data
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const verify = createAsyncThunk<{ message: string }, { code: string }, { rejectValue: string }>("/auth/verify", async ({ code }, { rejectWithValue }) => {
    try {
        const data = await verifyUserApi(code)
        return data;
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const resendEmail = createAsyncThunk<{ message: string }, IResendVerificationEmaiPayload, { rejectValue: string }>("/auth/resend-verify-email", async (payload, { rejectWithValue }) => {
    try {
        const data = await resendEmailApi(payload)
        return data
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const forgotPassword = createAsyncThunk<{ message: string }, IForgotPasswordPayload, { rejectValue: string }>("/auth/forgot-password", async (payload, { rejectWithValue }) => {
    try {
        const data = await forgotPasswordApi(payload)
        return data;
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const updateProfile = createAsyncThunk<IUser, IUpdateMyProfilePayload, { rejectValue: string }>("/auth/updateMyProfile", async (payload, { rejectWithValue }) => {
    try {
        const data = await updateMyProfileApi(payload)
        return data;
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const logout = createAsyncThunk<boolean, void, { rejectValue: string }>("/auth/logout", async (_, { rejectWithValue }) => {
    try {
        await logoutApi()
        return true
    } catch (error) {
        return rejectWithValue(error instanceof Error ? error.message : "Unknown error");
    }
})

export const getCurrent = createAsyncThunk<
  IAuthResponse,
  void,
  { rejectValue: string; state: RootState }
>("auth/current", async (_, { getState, rejectWithValue }) => {
  try {
    const token = getState().auth.token;
    const data = await getCurrentApi(token);
    return data;
  } catch (error) {
    return rejectWithValue(
      (error as AxiosError<{ message: string }>).response?.data?.message ||
        (error as AxiosError).message
    );
  }
});